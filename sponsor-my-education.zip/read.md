NAB ACCREDITED
OFQUAL REGULATED
GLOBALLY RECOGNIZED

QUICK FIXES

1. Insert facebook link to the facebook icon: htpps://m.facebook.com/ghscholars
2. Work on logo size on mobile screens
3. Insert a Copyright warning
4. Find nice colours for the website
5.
